﻿using ChromediaARCE.Model;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ChromediaARCE
{
    class Program
    {
        public static List<DataModel> allPageModels = new List<DataModel>();
        static void Main(string[] args)
        {
            var intTopArticlesLimit = -1;
            do
            {
                intTopArticlesLimit = LoadAgain(Console.ReadLine());
            }
            while (intTopArticlesLimit <= 0);

            var pageCount = GetPageCount();
            if (pageCount > 1)
            {
                for (int i = 2; i < pageCount; i++)
                    GetPage(i);

                var decOrderByCommentCount = allPageModels.OrderByDescending(o => o.num_comments).ToList();
                decOrderByCommentCount.RemoveAll(r => string.IsNullOrEmpty(r.title) && string.IsNullOrEmpty(r.story_title));
                for (int i = 0; i < intTopArticlesLimit; i++)
                {
                    var title = string.IsNullOrEmpty(decOrderByCommentCount[i].title) ? decOrderByCommentCount[i].story_title : decOrderByCommentCount[i].title;
                    Console.WriteLine(title);
                }
                Console.Read();
            }

        }

        private static int LoadAgain(string strTopArticlesLimit)
        {
            var intTopArticlesLimit = -1;
            if (!int.TryParse(strTopArticlesLimit, out intTopArticlesLimit))
                Console.WriteLine("Please input integer only");

            return intTopArticlesLimit;
        }
        private static int GetPageCount()
        {
            var pageResult = GetPage(1);
            if (pageResult == null)
                return -1;
            return pageResult.total_pages;
        }
        private static PageModel GetPage(int page)
        {
            var restApi = new RestBase(page);
            var request = new RestRequest(Method.GET);
            var pageResult = restApi.Execute<PageModel>(request);
            if (pageResult == null)
                return null;
            allPageModels.AddRange(pageResult.data);
            return pageResult;
        }
    }
}
