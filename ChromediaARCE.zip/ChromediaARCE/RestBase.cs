﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChromediaARCE
{
    public class RestBase
    {
        private readonly string BaseUrl = string.Empty;
        readonly IRestClient _client;

        public RestBase(int page)
        {
            BaseUrl = "https://jsonmock.hackerrank.com/api/articles?page=" + page;
            _client = new RestClient(BaseUrl)
            {
                Timeout = 60000,
                ReadWriteTimeout = 60000
            };
        }
        public T Execute<T>(RestRequest request) where T : new()
        {
            var response = _client.Execute<T>(request);

            if (response.ErrorException != null)
            {
                string message = "Error retrieving response. " + response.ErrorException.Message;
                var paymentRestException = new ApplicationException(message, response.ErrorException);
                throw paymentRestException;
            }
            if (response.StatusCode != System.Net.HttpStatusCode.OK)
            {
                string message = "Error retrieving response. StatusCode is " + response.StatusDescription + " .Content is " + response.Content;
                var paymentRestException = new ApplicationException(message);
                throw paymentRestException;
            }
            return response.Data;
        }
    }
}
